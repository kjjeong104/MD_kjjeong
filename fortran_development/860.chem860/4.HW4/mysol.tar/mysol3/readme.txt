The third problem stated the following:

Convert the LJ Metropolis code in order to calculate P versus density in an N, P, T ensemble following class notes 
and/or the Algorithms 10 and 11 of the text.  Do this for any three points in Figure 5.3.  
Include error estimates and describe how they were calculated.

You may use the code here.  It is already set up and running for an N, P, T ensemble.  Almost.  
It still needs the long rang corrections for the energy to be included.
